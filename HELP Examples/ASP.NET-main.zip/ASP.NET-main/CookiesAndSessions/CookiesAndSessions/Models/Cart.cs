﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CookiesAndSessions.Models
{
    public class Cart
    {
        public DateTime DateTime { get; set; }
        public int Count { get; set; }
    }
}
